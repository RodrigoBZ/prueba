library(testthat)
library(bw)

test_check("bw")
